<?php
/*
Directions to get the Consumer key, Consumer secret, Access token and Access token secret:<br>
1. Add a new Twitter application - https://dev.twitter.com/apps/new
2. Fill in Name, Description, Website, and Callback URL (don't leave any blank) with anything you want
3. Agree to rules, fill out captcha, and submit your application
4. Copy the Consumer key, Consumer secret, Access token and Access token secret into the variables below
*/
define('_username', 'quanticalabs');
define('_tweets_count', '10');

define('_consumer_key', '');
define('_consumer_secret', '');
define('_access_token', '');
define('_access_token_secret', '');
?>