<?php
    class RegisterController extends AppController
    {
        function index()
        {
            
        }
    }
?>